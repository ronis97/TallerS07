 

public class Ubicacion {
    private int longitud;
    private int latitud;
    public int getlongitud(){
        return longitud;
    }
    public int getlatitud(){
        return latitud;
    }
}
