 

public class Avion{
	private String placa;
	private boolean enAire;
	private Marino piloto;
	private Marino copiloto;
}
